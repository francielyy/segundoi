Alunas: Francini Braga 11
        Gabriely Cerine 14

#Falta de incentivo a leitura 

#1 trimestre:
Falta de incentivo a leitura: porque isso é um problema, como podemos aumentar o incentivo, onde deveriam incentiv-la 

2 trimestre:
Leiura eletista 

3 trimestre:
Com as telas atraplaham no interesse da leitura

